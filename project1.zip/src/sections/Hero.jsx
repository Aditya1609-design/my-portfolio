import React from 'react';
import heroGif from '../assets/hero.gif';

const Hero = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 to-white">
      <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center">
        {/* Left Side */}
        <div className="w-full md:w-1/2 mb-10 md:mb-0 text-left">
          <h2 className="text-5xl font-extrabold text-gray-900 mb-6">
            Hi, I'm <span className="text-blue-600">Aditya</span> 👋
          </h2>
          <p className="text-xl text-gray-700 mb-8">
            I’m a developer focused on building beautiful, functional, and fast web experiences.
          </p>
          <a
            href="#contact"
            className="inline-block px-6 py-3 bg-blue-600 text-white text-lg font-semibold rounded-full shadow hover:bg-blue-700 transition"
          >
            Let’s Connect
          </a>
        </div>

        {/* Right Side */}
        <div className="w-full md:w-1/2 flex justify-center">
          <img
            src={heroGif}
            alt="Developer Animation"
            className="w-80 h-80 object-contain"
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;
